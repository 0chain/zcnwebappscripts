\connect blobber_meta;

GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO blobber_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO blobber_user;